<?php

//requests login page
$view = new stdClass();
$view->pageTitle = 'Login';
require_once('..\Views\Login.phtml');
