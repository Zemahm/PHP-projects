<?php
require_once '../Models/CampsitesDataset.php';
$view = new stdClass();//generic class
$view->pageTitle = 'Campsites';//title
$campsiteDataset = new CampsiteDataset();//new campsite Dataset
$view->campsiteDataset = $campsiteDataset->fetchAllCampsites();// returns array of campsite data
require_once('..\Views\Campsites.phtml');