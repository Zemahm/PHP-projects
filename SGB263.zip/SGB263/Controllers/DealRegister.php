<?php

require_once('../Models/Register.php');
require_once('../Models/Image.php');
if (isset($_POST['submitButton'])) {


    $imageConfObj = null;
    if (isset($_FILES['image']) and $_FILES['image'] != null and $_FILES['image']['tmp_name'] != "") {


        //defines image properties
        $image = $_FILES['image'];
        $fileName = $image['name'];
        $fileTmpName = $image['tmp_name'];

        $fileSize = $image['size'];
        $fileError = $image['error'];
        //  file type is entered to be verified as jpg/jpeg/png in imageConfObj
        $fileType = $image['type'];


        //ImageConf class has functions which will validate the type of image
        $imageConfObj = new ImageConf($image, $fileName, $fileTmpName, $fileSize, $fileType, $fileError);
        $imageConfObj->validateImage();
    }


//loads of if statements, else statements always make variables explicitly null for register class field verification
    if (isset($_POST['forename'])) {
        $forename = $_POST['forename'];
    } else {
        $forename = null;
    }
    if ($_POST['surname']) {
        $surname = $_POST['surname'];
    } else {
        $surname = null;
    }
    if ($_POST['email']) {
        $email = $_POST['email'];
    } else {
        $email = null;
    }
    if ($_POST['password']) {
        $password = $_POST['password'];
    } else {
        $password = null;
    }
    if ($_POST['address1']) {
        $address1 = $_POST['address1'];
    } else {
        $address1 = null;
    }
    if ($_POST['address2']) {
        $address2 = $_POST['address2'];
    } else {
        $address2 = null;
    }
    if ($_POST['address3']) {
        $address3 = $_POST['address3'];
    } else {
        $address3 = null;
    }
    if ($_POST['city']) {
        $city = $_POST['city'];
    } else {
        $city = null;
    }
    if ($_POST['phoneNum']) {
        $phoneNum = $_POST['phoneNum'];
    } else {
        $phoneNum = null;
    }
    //checks if imageConfObj was created and confirms for upload of image, uses methods to generate name and is saved
    if ($imageConfObj != null and $imageConfObj->canUpload()) {

        $imageConfObj->saveImage('../images/ProfileImages/');
        $filePath = $imageConfObj->getFinalFilePath();
    } else {
        $filePath = "Image Not Given";
    }
    $regObj = new regInfo($forename, $surname, $email, $password, $address1, $city, $address2, $address3, $phoneNum, $filePath);

    //this is incomplete, page has to refresh for cookies to set
    if ((!(empty($regObj->getDeformedEntries()))) or $imageConfObj != null and !(empty($imageConfObj->getDeformedEntries()))) {


        //in the future this arrays will be passed on to the register form to display all errors

        if (!(empty($regObj->getDeformedEntries()))) {
//            if (isset($_COOKIE['regObjErrors'])) {
//                setcookie('regObjErrors', $regObj->getDeformedEntries(), time() - 120);
//            }
//            setcookie('regObjErrors', $regObj->getDeformedEntries(), time() + 120);

        }

        if ($imageConfObj != null and !(empty($imageConfObj->getDeformedEntries()))) {

//            if (!(empty($imageConfObj->getDeformedEntries()))) {
//                if (isset($_COOKIE['imageConfErrors'])) {
//                    setcookie('imageConfErrors', $imageConfObj->getDeformedEntries(), time() - 120);
//                }
//
//                $_COOKIE['imageConfErrors'] = $imageConfObj->getDeformedEntries();
//            }

        }

        header("Location: ../Controllers/Register.php");
        exit();
    }
    else{
        $regObj->enterData();

        header("Location: ../Controllers/login.php");
        exit();
    }

}