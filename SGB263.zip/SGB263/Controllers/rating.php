<?php
/**
 * Created by PhpStorm.
 * User: zmahm
 * Date: 19/12/2018
 * Time: 14:16
 */
session_start();
require_once('../Models/UserData.php');
require_once('../Models/rating.php');
require_once('../Models/UserData.php');
require_once('../Models/CampsiteData.php');

// checks if post variables isset and validates if form sent right data
if (isset($_SESSION['USER']) and isset($_POST['rate']) and  isset($_POST['data']) )
{


    if ( $_POST['rate']== "1" or $_POST['rate']== "2" or $_POST['rate']== "3" or $_POST['rate']== "4" or $_POST['rate']== "5") {
        $user = UserData::cast( unserialize($_SESSION['USER']));
        $campsite = CampsiteData::_cast(unserialize(base64_decode($_POST['data'])));
        $usrRating = $_POST['rate'];


        $rating = new rating($campsite, $usrRating, $user);
        if ($rating->canRate()) {

            $user->setRatedList($rating->formatList());
            $_SESSION['USER'] = serialize($user);
            $rating->updateList();
            $rating->confirmRating();

        }

    }
}
//returns to campsites page
header('Location:../Controllers/Campsites.php');
exit();