<?php
require_once ('../Models/UserData.php');
session_start();
if (isset($_SESSION['USER'])) {
    //checks if cookie exists, if so adds to cookie and if not creates then adds
$user = UserData::cast(unserialize($_SESSION['USER']));
    if (isset($_POST['cInfo'])) {
// implode is used instead of serialize because of possible security holes, unserialize can end up running user inputted code
        $info = htmlentities($_POST['cInfo']);
        if (isset($_COOKIE[$user->getUserId()])) {
            $arr = explode(",", $_COOKIE['fav']);

            if (!(in_array($info, $arr))) {

                array_push($arr, $info);
                setcookie(''. $user->getUserId() .'', implode(",", $arr), time() + 86400 * 30);//unique cookie is made using user ID
            }
        } else {
            $arr = array();
            array_push($arr, $info);
            setcookie($user->getUserId(), implode(",", $arr), time() + 86400 * 30);//unique cookie is made using user ID
        }

        // header("Location:../Controllers/Favourites.php");
        header("Refresh:0");
        header("Location:../Controllers/Favourites.php");
        exit();
    }
} else {
    //redirects to login if user isn't logged in
    header("Location:../Controllers/login.php");
    exit();


}