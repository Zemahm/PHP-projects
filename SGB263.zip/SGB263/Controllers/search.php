<?php
$view = new stdClass();
$view->pageTitle = 'Campsites';
//takes input from search bar in header and searches by name using Search class
require_once('../Models/search.php');
if (isset($_POST['search'])) {
    $searchItem = $_POST['search'];
    $search = new search($searchItem);

    //search filters
    $attribute = "CampsiteName";
    if (isset($_POST['attribute']) and $_POST['attribute'] === 'name') {
        $attribute = "CampsiteName";
    }
    if (isset($_POST['attribute']) and $_POST['attribute'] === 'facilities') {
        $attribute = "Facilities";
    }
    if (isset($_POST['attribute']) and $_POST['attribute'] === 'city') {
        $attribute = "City";

    }
    $view->campsiteDataset = $search->search($attribute);

}
else {
    $view->campsiteDataset = null;
}

require_once('..\Views\Campsites.phtml');