<?php
$view = new stdClass();
$view->pageTitle = 'Register';


//checks for existing errors doesnt work, this should only be done with js

//if (isset($_COOKIE['regObjErrors'])) {
//    $view->regEntryErrors = $_POST['regObjErrors'];
//}
//else{
//    $view->regEntryErrors = null;
//}
//if (isset($_COOKIE['imageConfErrors'])) {
//    $view->regImageErrors =$_POST['imageConfErrors'];
//     }
//     else{
//         $view->regImageErrors =null;
//     }
//     var_dump($view->regEntryErrors,$view->regImageErrors);
require_once('../Views/RegisterNew.phtml');