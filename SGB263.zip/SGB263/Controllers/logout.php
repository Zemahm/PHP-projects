<?php
session_start();

//clears out session variable then redirects to home page
if (isset($_SESSION['USER'])){
    unset($_SESSION['USER']);
    header('Location: ../index.php');
}