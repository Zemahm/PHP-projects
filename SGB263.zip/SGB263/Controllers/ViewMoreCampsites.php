<?php
include_once('../Models/CampsiteData.php');
include_once ('../Models/CampsitesDataset.php');
$view = new stdClass();
$view->pageTitle = 'Campsite Details';

if(isset($_POST['campsiteInfo'])){
    //this method unserializes then decodes into an object then is type casted so methods can be used


//    var_dump(unserialize(base64_decode($_POST['campsiteInfo'])));
//    die();
    $campsiteData = CampsiteData::_cast(unserialize(base64_decode($_POST['campsiteInfo'])));

    $newMonthlyClicks = $campsiteData->getMonthlyClicks() + 1;
    $newOverallClicks = $campsiteData->getOverallClicks() + 1;
    $id = $campsiteData->getCampsiteId();

    $dataset = new CampsiteDataset();
    $dataset->updateClicksByID($newMonthlyClicks,$newOverallClicks,$id);

    $view = new stdClass();
    $view->campsiteData = $campsiteData;
    $view->pageTitle= "Full details for " .$campsiteData->getCampsiteName();
    require_once('../Views/ViewMoreCampsites.phtml');
   //var_dump($view->campsiteData);
}
else{
    header('../../index.php');
    exit();
}

