<?php

require_once('..\Models\UserDataset.php');

//for admin interface
$view = new stdClass();
$view->pageTitle ='User Data';
$userDataset = new UserDataset();
$view->userDataset = $userDataset->fetchAllUsers();


require_once('..\Views\UserData.phtml');

