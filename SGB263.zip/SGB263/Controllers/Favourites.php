<?php
    require_once('../Models/CampsitesDataset.php');
    require_once ('../Models/UserData.php');
//creates new dataset object and calls fetch by id, configured to use campsite id's
if (session_status() == 1) {
    session_start();
}
if (isset($_SESSION['USER'])) {
    $campData = new CampsiteDataset();
    //unsserializes then casts into UserData object
$user = UserData::cast(unserialize($_SESSION['USER']));

//creates unique named cookies
    if (isset($_COOKIE[$user->getUserId()])) {
        $fav = explode(",", $_COOKIE[$user->getUserId()]);

    } else {
        setcookie($user->getUserId(), "", time() + 86400 * 30);

        if(isset($_COOKIE[$user->getUserId()])){
            $fav = explode(",", $_COOKIE[$user->getUserId()]);
        }
    }

    //with php pages need to be refreshed manually, page refreshes till cookie is set
    if (!(isset($_COOKIE[$user->getUserId()]))) {

        header("Location: ../index.php");
    } else {


        $view = new stdClass();
        $view->pageTitle = "Favourites";
        $view->campsiteDataset = $campData->fetchByID($fav, "favourites");;
        require_once('../Views/Campsites.phtml');
        exit();
    }
}
