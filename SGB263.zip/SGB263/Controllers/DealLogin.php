<?php
require_once('../Models/Login.php');
require_once($_SERVER['DOCUMENT_ROOT'] .'/Models/UserData.php');

session_start();
//echo'test';
if (isset($_POST['email']) and $_POST['password']) {
//echo 'test';
//sleep(5);


    $email = $_POST['email'];
    $password = $_POST['password'];

    $loginObj = new login($email, $password);

    if ($loginObj->confirmation()) {

        //explicit unset is used in case of user fiddling

        if (isset($_SESSION['USER'])) {
            unset($_SESSION['USER']);

        } else {


            //serialized to ensure state stability
          $user = serialize($loginObj->getUserInfo());

            $_SESSION['USER'] = $user;




        }
//redirects to home page
            header('Location: ../index.php');
           exit();


    } else {
        //if not confirmed returns to login
        header('Location: ../Controllers/login.php');
        exit();

    }
}
