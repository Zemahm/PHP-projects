<?php
//homepage placed here for server to find
$view = new stdClass();
$view->pageTitle = 'Homepage';
require_once('Views\index.phtml');

