<?php
/**
 * User: zmahm
 * Date: 02/04/2019
 * Time: 20:36
 *
 * purpose of this class is to hold an instance of date. makes scripts less messy and less upkeep
 */

class date
{
    private $_seconds,$_minutes;

}