<?php

require_once("Database.php");

class regInfo
{
    private $_forename, $_surname, $_imagePath, $_email, $_password, $_address1, $_address2, $_address3, $_city, $_deformedEntries, $_phoneNum;


    protected $_registerInfo = null, $_dbHandle, $_dbInstance;

    function __construct($forename, $surname, $email, $password, $address1, $city, $address2, $address3, $phoneNum, $filePath)
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();

        $this->_deformedEntries = array();//used in echoing out errors
        $this->_forename = $forename;
        $this->_surname = $surname;
        $this->_email = $email;
        $this->_password = $password;
        $this->_address1 = $address1;
        $this->_city = $city;

        $this->_imagePath = $filePath;
        $this->_address2 = $address2;
        $this->_address3 = $address3;
        $this->_phoneNum = $phoneNum;

//verifies fields for wrong input and encrypts password
        $this->verifyFields();
        $this->encryptPassword();
    }

    /**
     * @return mixed
     */
    public function getPhoneNum()
    {
        return $this->_phoneNum;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->_password = $password;
    }

    /**
     * @return mixed
     */
    public function getCity()
    {
        return $this->_city;
    }

    /**
     * @return array
     */
    public function getDeformedEntries()
    {
        return $this->_deformedEntries;
    }


    /**
     * @return mixed
     */
    public function getForename()
    {
        return $this->_forename;
    }

    /**
     * @return mixed
     */
    public function getSurname()
    {
        return $this->_surname;
    }

    /**
     * @return mixed
     */
    public function getImagePath()
    {
        return $this->_imagePath;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->_email;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->_password;
    }

    /**
     * @return mixed
     */
    public function getAddress1()
    {
        return $this->_address1;
    }

    /**
     * @return mixed
     */
    public function getAddress2()
    {
        return $this->_address2;
    }

    /**
     * @return mixed
     */
    public function getAddress3()
    {
        return $this->_address3;
    }

//checks if email exists, if not data is entered using PDO object
    public function enterData()
    {

            //checking if email exists
        if ($this->doesEmailExist($this->getEmail()) == false) {

            $sqlQuery = ' INSERT INTO User(Forename, Surname, Email, Address1, Address2, Address3, City,ProfileImage, Password, PhoneNum)             
              ' . "VALUES(?,?, ?,?, ?, ?,?,?,?,?)";


            $statement = $this->_dbHandle->prepare($sqlQuery);
            $statement->bindParam(1, $this->_forename, PDO::PARAM_STR);
            $statement->bindParam(2, $this->_surname, PDO::PARAM_STR);
            $statement->bindParam(3, $this->_email, PDO::PARAM_STR);
            $statement->bindParam(4, $this->_address1, PDO::PARAM_STR);
            $statement->bindParam(7, $this->_city, PDO::PARAM_STR);
            $statement->bindParam(9, $this->_password, PDO::PARAM_STR);

           //optional fields
            if ($this->getImagePath() === null) {
                $imgNotGiven = 'Image Not Given';
                $statement->bindParam(8, $imgNotGiven, PDO::PARAM_STR);
            } else {
                $statement->bindParam(8, $this->_imagePath, PDO::PARAM_STR);
            }

            if ($this->getAddress2() === null) {
                $notEntered = 'Not Entered';
                $statement->bindParam(5, $notEntered, PDO::PARAM_STR);
            } else {
                $statement->bindParam(5, $this->_address2, PDO::PARAM_STR);

            }
            if ($this->getAddress3() === null) {
                $notEntered = 'Not Entered';
                $statement->bindParam(6, $notEntered, PDO::PARAM_STR);
            } else {
                $statement->bindParam(6, $this->_address3, PDO::PARAM_STR);

            }
            if ($this->getPhoneNum() === null) {
                $notEntered = 'Not Entered';
                $statement->bindParam(10, $notEntered, PDO::PARAM_STR);
            } else {
                $statement->bindParam(10, $this->_phoneNum, PDO::PARAM_STR);

            }
            $statement->execute();



        }
        else{
            array_push($this->_deformedEntries, "This email exists, please try another");

        }
    }

    //checks if email exists in database, parameter is for extra usability, when logging in a reg object is called and this method is used
    public function doesEmailExist($email)
    {

        $lEmail = $email;
        if ($lEmail == null) {
            $lEmail = $this->getEmail();
        }


        $sqlQuery = 'SELECT Email FROM User WHERE Email = ?';

        $statement = $this->_dbHandle->prepare($sqlQuery);//gets the SQL statement ready


        $statement->bindValue(1, $lEmail);

        $statement->execute();//executes statement



        $checkEmail = $statement->fetch();



        if ($checkEmail[0] === $lEmail) {
            $emailExist = true;

            array_push($this->_deformedEntries,"This email exists, please try another");
        } else {
            $emailExist = false;

        }

        return $emailExist;


    }


    /**
     * This method verifies all fields needed to prevent unintended data entry with special characters
     */
    private function verifyFields()
    {
        //checks if any fields are empty and adds to deformed entries array

        if ($this->getImagePath() == null){
            array_push($this->_deformedEntries, "Not all required data was entered. img path");
        }
        if ($this->getSurname() == null) {
            array_push($this->_deformedEntries, "Not all required data was entered. surname");
        }
        if ($this->getEmail() == null) {
            array_push($this->_deformedEntries, "Not all required data was entered. email");
        }
        if ($this->getPassword() == null) {
            array_push($this->_deformedEntries, "Not all required data was entered. password");
        }
        if ($this->getAddress1() == null){
            array_push($this->_deformedEntries, "Not all required data was entered. address1");
        }
        if ($this->getCity() == null) {
            array_push($this->_deformedEntries, "Not all required data was entered. city");
        }

            //cannot use getDeformedEntries, array_push only allows direct variable calls
        if (preg_match('/[\'^£$%&*()}{@#~?><>.,|=_+¬]/', $this->getForename()) || preg_match('/^[0-9]/', $this->getForename())) {
            array_push($this->_deformedEntries, "Forename cannot contain any special characters or numbers.");
        }

        if (preg_match('/[\'^£$%&*()}{@#~?><>.,|=_+¬]/', $this->getSurname()) || preg_match('/^[0-9]/', $this->getSurname())) {
            array_push($this->_deformedEntries, "Surname cannot contain any special characters or numbers.");
        }

        if (preg_match('/[\'^£$%&*()}{#~?><>,|=_+¬-]/', $this->getEmail())) {
            array_push($this->_deformedEntries, "Email cannot contain any special characters.");
        }
        if (!(preg_match('/[@]/', $this->getEmail()))) {
            array_push($this->_deformedEntries, "Email entry is not an email.");
        }

        if (preg_match('/[\'^£$%&*()}{@#~?><>.,|=_+¬-]/', $this->getAddress1())) {
            array_push($this->_deformedEntries, "Addresses cant contain special characters.(Address 1)");
        }
        if ($this->getAddress2() != null) {
            if (preg_match('/[\'^£$%&*()}{@#~?><>.,|=_+¬-]/', $this->getAddress2())) {
                array_push($this->_deformedEntries, "Addresses cant contain special characters.(Address 2)");
            }
        }
        if ($this->getAddress3() != null) {
            if (preg_match('/[\'^£$%&*()}{@#~?><>.,|=_+¬-]/', $this->getAddress3())) {
                array_push($this->_deformedEntries, "Addresses cant contain special characters. Address 3");
            }
        }

        if ($this->getPhoneNum() != null) {
            if (!(strlen($this->getPhoneNum())==11 or strlen($this->getPhoneNum())==12 and ctype_alnum($this->getPhoneNum()))) {
                array_push($this->_deformedEntries, "Phone Numbers cannot have non-numerical characters in them and must be 11-12 numbers long.");
            }
        }
    }

    //encrypts password using MD5
    private function encryptPassword()
    {
        $this->setPassword(md5($this->getPassword()));
    }
}

