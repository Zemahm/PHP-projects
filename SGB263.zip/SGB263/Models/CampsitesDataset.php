<?php
require_once 'Database.php';
require_once 'CampsiteData.php';
require_once 'UserData.php';



//class is used to obtain campsite information using PDO objects with  prepared statements
class CampsiteDataset
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }
//uses pdo to retrieve all campsites
    public function fetchAllCampsites()
    {
        $sqlQuery = 'SELECT * FROM Campsite as camp INNER JOIN (select UserID, PhoneNum, Email FROM User) as User ON OwnerID = UserID';

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $campsite = new CampsiteData($row);

            array_push($dataSet, $campsite);
            //$dataSet[] = $campsite;
        }
        return $dataSet;
    }


    public function fetchMostMonthlyViewed($wholeResults, $order){// gets highest 5 viewed campsites (monthly) if param is true if not just shows whole table, 2nd param sets if ordered by ascending or descending

        if ($order === "ASC" or $order === "DESC") {// little check to make sure no javascript misuse
            $sqlQuery = 'SELECT * FROM (SELECT * FROM Campsite ORDER BY MonthlyClicks ' . $order . ') as camp INNER JOIN (select UserID, PhoneNum, Email FROM User ) as User ON OwnerID = UserID';

            $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
            $statement->execute(); // execute the PDO statement

            if ($wholeResults == false) {
                $dataSet = [];
                while ($row = $statement->fetch()) {
                    $campsite = new CampsiteData($row);

                    array_push($dataSet, $campsite);
                    //$dataSet[] = $campsite;
                }
                return $dataSet;
            } else {
                $inc = 0;
                $dataSet = [];
                while ($row = $statement->fetch()) {
                    if ($inc == 5) {
                        break;
                    }
                    $campsite = new CampsiteData($row);

                    array_push($dataSet, $campsite);
                    //$dataSet[] = $campsite;
                    $inc++;
                }
                return $dataSet;


            }
        }

    }

    public function updateClicksByID($newMonthlyClicks,$newOverallClicks, $ID){
        $sqlQuery='UPDATE Campsite set MonthlyClicks = ? WHERE CampsitesID = ?';
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->bindParam(1, $newMonthlyClicks);
        $statement->bindParam(2, $ID);

        $statement->execute(); // execute the PDO statement


        $sqlQuery='UPDATE Campsite set OverallClicks = ? WHERE CampsitesID = ?';
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->bindParam(1, $newOverallClicks);
        $statement->bindParam(2, $ID);

        $statement->execute(); // execute the PDO statement




    }

    public function fetchMostViewed($wholeResults, $order){// gets highest 5 viewed campsites (all together) if param is true if not just shows whole table, 2nd param sets if ordered by ascending or descending

        if ($order === "ASC" or $order === "DESC") {// little check to make sure no javascript misuse
            $sqlQuery = 'SELECT * FROM (SELECT * FROM Campsite ORDER BY OverallClicks ' . $order . ') as camp INNER JOIN (select UserID, PhoneNum, Email FROM User ) as User ON OwnerID = UserID';

            $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
            $statement->execute(); // execute the PDO statement

            if ($wholeResults == false) {
                $dataSet = [];
                while ($row = $statement->fetch()) {
                    $campsite = new CampsiteData($row);

                    array_push($dataSet, $campsite);
                    //$dataSet[] = $campsite;
                }
                return $dataSet;
            } else {
                $inc = 0;
                $dataSet = [];
                while ($row = $statement->fetch()) {
                    if ($inc == 5) {
                        break;
                    }
                    $campsite = new CampsiteData($row);

                    array_push($dataSet, $campsite);
                    //$dataSet[] = $campsite;
                    $inc++;
                }
                return $dataSet;


            }
        }
    }






    //this method is used for finding favourites and for owners to see what campsites they own, config variable is used to specify type of query that is being done
    public function fetchByID($arr, $config)
    {

        $dataset = array();
        //this if statement is for searching by owner id
        if ($config === "ownerid") {
            if (!(is_array($arr))) {
                $sqlQuery = 'SELECT * FROM Campsite as camp INNER JOIN (select UserID, PhoneNum, Email FROM User) as User ON OwnerID = UserID AND CampsitesID = ?';
                $statemnt = $this->_dbHandle->prepare($sqlQuery);
                //binds with parameters marked as ? in $sqlQuery
                $statemnt->bindParam(1, $arr);
                $statemnt->execute();
                while ($row = $statemnt->fetch()) {
                    $camp = new CampsiteData($row);
                    array_push($dataset, $camp);
                }

            }
            return $dataset;

        }
        //this this section is used in by searching for favourites when configured to
        elseif ($config === "favourites") {
            if (is_array($arr)) {

                foreach ($arr as $id) {
                $sqlQuery = 'SELECT * FROM Campsite as camp INNER JOIN (select UserID, PhoneNum, Email FROM User) as User ON OwnerID = UserID AND CampsitesID = ?';
                $statement = $this->_dbHandle->prepare($sqlQuery);
                    //binds with parameters marked as ? in $sqlQuery
                    $statement->bindParam(1, $id);
                $statement->execute();

                    $campsite = new CampsiteData($statement->fetch());
                    array_push($dataset, $campsite);
                }


            }
            return $dataset;
        }

    }
}
