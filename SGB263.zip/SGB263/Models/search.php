<?php
require_once('Database.php');
require_once('CampsiteData.php');
require_once('UserData.php');
//search class takes search from header, inserts into query using bindParam method
class search
{
    private $_searchItem, $_dbHandle, $_dbInstance;

    public function __construct($searchItem)
    {

        $this->_searchItem = htmlentities($searchItem);
        $this->_searchItem = "%".$this->_searchItem."%";
        //from static Database class
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();

    }
//takes parameter of which attribute to search by either which city, facilities or campsite name

    public function search($attribute)
    {
        //checks attribute from method call in controller and uses query that matches
        if ($attribute === "City"){

            $sqlQuery = "SELECT * FROM(select * from Campsite) as camp INNER JOIN (select  UserID,Email,PhoneNum FROM User) as User ON OwnerID = UserID and City like ?";

        }
        elseif ($attribute ==='Facilities'){

            $sqlQuery = "SELECT * FROM(select * from Campsite) as camp INNER JOIN (select  UserID,Email,PhoneNum FROM User) as User ON OwnerID = UserID and Facilities like ?";

        }
        else{

            $sqlQuery = "SELECT * FROM(select * from Campsite) as camp INNER JOIN (select  UserID,Email,PhoneNum FROM User) as User ON OwnerID = UserID and CampsiteName like ?";

        }



        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(1, $this->_searchItem);
        $statement->execute();
//var_dump($statement->fetch());
//die();
        $dataset = array();
        while ($row = $statement->fetch()) {
            $campsite = new CampsiteData($row);

            array_push($dataset, $campsite);
        }
        return $dataset;//data collection
    }


}