<?php

class ImageConf
{
    //purpose of this class is to be able to be used to store images into the images folder also making sure certain image requirements are met, useful when attempts to bypass javascript have been made
    private $_image, $_fileName, $_fileTmpName, $_fileSize, $_fileType, $_fileError, $_deformedEntries, $_allowed, $_fileExt, $_finalFilePath;


    function __construct($image, $filename, $fileTmpName, $fileSize, $fileType, $fileError)
    {
        $this->_fileName = $filename;
        $this->_image = $image;
        $this->_fileTmpName = $fileTmpName;
        $this->_fileSize = $fileSize;
        $this->_fileType = $fileType;
        $this->_fileError = $fileError;
        $this->_deformedEntries = array();

        //permissible file types
        $this->_allowed = array('jpg', 'jpeg', 'png');

        //makes sure that file ext is lowercase
        $this->_fileExt = explode('.', $this->_fileName);
        $this->_fileExt = strtolower(end($this->_fileExt));
    }


       
    // this method identifies all the unsuitable attributes a file uploaded has, too big file size, wrong file type and if there was an error denies upload
    public function validateImage()
    {
        $check = false;
        //cannot use get method for array because this method only supports direct variable call of array
        if (!(in_array($this->getFileExt(), $this->_allowed))) {

            array_push($this->_deformedEntries, "This type of file is not allowed");
            $check =false;
        }

        if ($this->getFileSize() > 5000000) {

            array_push($this->_deformedEntries, "File size too high");
            $check = false;
        }

        return $check;

    }

    public function canUpload()
    {
        $image = getimagesize($this->getFileTmpName());// and $image[0] >! 400 and $image[1] >! 400
        if (is_array($image) and $this->validateImage()) { //guarantees file is an image
            $validate = true;
        }

        else {
            $validate = false;

        }
        return $validate;

    }

// this function saves the image after making sure it meets the specifications of file size limit and also adjusts to a right size

    public function saveImage($saveLocation)
    {
        if ($this->canUpload()) {
            $image = $this->getFileTmpName();
            if( $image[0] >! 400 and $image[1] >! 400){// means image does not reach specs needed

                $ext =  $this->_fileExt;

                if ($ext === "png"){
                   $newImg =  imagecreatefrompng($this->_fileName);//happens when image is png

                }


                else{
                    $newImg = imagecreatefromjpeg($this->_fileName); //happens when image is jpeg
                }


            }

                $saveDestination = "";
                while (true) {
                    //uses time to generate unique id so cool o.o, more entropy allows more pseudo randomness
                    $generatedFileName = uniqid('', true) . "." . $this->getFileExt();
                    $saveDestination = $saveLocation . $generatedFileName;
                    //makes sure filename is unique
                    if (!(file_exists($saveDestination))) {
                        break;
                    }


                }
                move_uploaded_file($this->getFileTmpName(), $saveDestination);
                $this->_finalFilePath = $saveDestination;


        }
    }

    /**
     * @return mixed
     */
    public function getFinalFilePath()
    {
        return $this->_finalFilePath;
    }


    /**
     * @return array
     */
    public function getAllowed()
    {
        return $this->_allowed;
    }

    /**
     * @return mixed
     */
    public function getFileExt()
    {
        return $this->_fileExt;
    }


    /**
     * @return mixed
     */
    public function getFileError()
    {
        return $this->_fileError;
    }


    /**
     * @return mixed
     */
    public function getImage()
    {
        return $this->_image;
    }

    /**
     * @return mixed
     */
    public function getFileName()
    {
        return $this->_fileName;
    }

    /**
     * @return mixed
     */
    public function getFileTmpName()
    {
        return $this->_fileTmpName;
    }

    /**
     * @return mixed
     */
    public function getFileSize()
    {
        return $this->_fileSize;
    }

    /**
     * @return mixed
     */
    public function getFileType()
    {
        return $this->_fileType;
    }

    /**
     * @return array
     */
    public function getDeformedEntries(): array
    {
        return $this->_deformedEntries;
    }


}