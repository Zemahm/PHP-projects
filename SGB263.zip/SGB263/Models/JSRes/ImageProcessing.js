class ImageProcessing{


    //The constructor here takes the 3 ID values needed for the genPrev method and imageConf method
    constructor() {
        //purposefully an array so errors can be dynamically added before being shown
        this.errors = [];
    };

    /**
     *     This method takes 3 ID's (preview image target, file details target and image insertion location)
     *     then sends image details to file details target and previews the image where the image target is
     *     -once the file has been confirmed to be an image and a reasonable size
     */

    genPrev(prevImg, fileDetailsID,fileButton, errorTarget){

        //variables preview and textOutput come from parameters
        var preview = document.getElementById(prevImg);
        var reader = new FileReader();
        var textOutput = document.getElementById(fileDetailsID);
        var errorOutput = document.getElementById(errorTarget);
        textOutput.innerHTML = "";
        errorOutput.innerHTML = "";
        var file = document.getElementById(fileButton).files[0];
        reader.addEventListener("load", function () {
            preview.src = reader.result;
        },false);

        //console.log(this.imageConf(file));
        if (this.imageConf(file)){
            if (file) {
                reader.readAsDataURL(file);
                textOutput.innerHTML = "Size: " + file.size + "File Type: " + this.getExtension(file);
            }
        }
        else {
            //loops around error array and concats to single string ready for error output
            var allErrors = "";
            this.errors.forEach(function (entry) {

               allErrors =  allErrors + entry;
            });
            errorOutput.innerHTML = allErrors;
            console.log(this.errors);

        }

    }

    //this method is called in genPrev() to confirm the file given is an image and is of a reasonable size
    imageConf(file){
        var check = true; // sets to false when there is at least one error

        var ext = this.getExtension(file);


         if (ext === 'jpg' || ext === 'jpeg' || ext === 'png'  ){
            //does nothing
        }
        else {
            this.errors.push(ext + " Type file type is not allowed .");
            check = false;
        }


       // console.log((file.size / 1024)/ 1024);
        if(((file.size / 1024)/1024)  > 5){
            //size is too big for file
            this.errors.push("File size too big. ");
            check = false;
        }
        return check;

    }
    //gets file extension
    getExtension(file){
        //separates filename and extension
        var  split = file.name.split('.');
        return split[1];
    }

}