<?php
require_once('../Models/Database.php');
require_once('../Models/Register.php');
require_once ('../Models/UserData.php');
class login{
private $_email, $_pass, $_deformedEntries, $_dbInstance, $_dbHandle, $_userInfo;
    function __construct($email,$pass)
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
        $this->_deformedEntries = array();
        $this->_email = $email;
        $this->_pass = md5($pass);
        $this->_userInfo = null;
        $this->validateFields();
    }

    /**
     * @return null
     */
    public function getUserInfo()
    {
        return $this->_userInfo;
    }

    /**
     * @param null $userInfo
     */
    public function setUserInfo($userInfo)
    {
        $this->_userInfo = new UserData($userInfo);
    }


//uses register object to confirm email using doesEmailExist() then does a another query to check if password inputted matches with email
    public function confirmation(){
        $passExist = false;
        if($this->getEmail() != null and $this->getPass() !=null){
            $conf = new regInfo(null,null,null,null,null,null,null,null,null,null);
            if($conf->doesEmailExist($this->getEmail())){
                //only if email exists password is checked to match

                $sqlQuery = 'SELECT * FROM User WHERE Email = ? AND Password = ?';

                $statement = $this->_dbHandle->prepare($sqlQuery);
                $statement->bindParam(1, $this->_email);
                $statement->bindParam(2, $this->_pass);
                $statement->execute();

                $checkPass = $statement->fetch();



                if($checkPass['Password'] === $this->getPass()){


                    $this->setUserInfo($checkPass);
                    return true;

                }
                else{
                    return false;
                }

            }
        }
        else{
            return $passExist;
        }

    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->_email;
    }

    /**
     * @return mixed
     */
    public function getPass()
    {
        return $this->_pass;
    }



    /**
     * @return mixed
     */
    public function getDeformedEntries()
    {
        return $this->_deformedEntries;
    }

//using regular expressions validates fields and inserts errors into deformed entries array
    private function validateFields(){
        if(preg_match('/[\'^£$%&*()}{#~?><>,|=_+¬-]/', $this->getEmail())){
            array_push($this->_deformedEntries, "Email cannot contain any special characters.");
        }
        if(!(preg_match('/[@]/', $this->getEmail()))){
            array_push($this->_deformedEntries, "Email entry is not an email.");
        }
    }


}