<?php
//This class is used to create collections of user data for admin operations
class UserData {

    protected $_userId, $_forename, $_surname, $_email, $_address1, $_address2, $_address3,$_city, $_profileImage, $_privileges, $_phoneNum,$_ratedList;


    public function __construct($dbRow) {

        $this->_userId = $dbRow['UserID'];
        $this->_forename = $dbRow['Forename'];
        $this->_surname = $dbRow['Surname'];
        $this->_email = $dbRow['Email'];
        $this->_address1 = $dbRow['Address1'];
        $this->_address2 = $dbRow['Address2'];
        $this->_address3 = $dbRow['Address3'];
        $this->_city = $dbRow['City'];
        $this->_profileImage = $dbRow['ProfileImage'];
        $this->_privileges = $dbRow['Privileges'];
        $this->_phoneNum = $dbRow['PhoneNum'];
        $this->_ratedList = $dbRow['ratedList'];
        $this->defRatedList();

    }


    private function defRatedList(){
        if ($this->_ratedList == null){
            $this->_ratedList = "no rating";
        }
    }



    //setter used for updating list
    /**
     * @param mixed $ratedList
     */
    public function setRatedList($ratedList)
    {
        $this->_ratedList = $ratedList;
    }

    //getters


    /**
     * @return mixed
     */
    public function getRatedList()
    {
        return $this->_ratedList;
    }

    public function getUserId() {
        return $this->_userId;
    }
    public function getForename() {
        return $this->_forename;
    }
    public function getSurname() {
        return $this->_surname;
    }
    public function getEmail() {
        return $this->_email;
    }

    /**
     * @return mixed
     */
    public function getPhoneNum()
    {
        return $this->_phoneNum;
    }


    /**
     * @return string
     */
    public function getPrivileges()
    {
        return $this->_privileges;
    }

    /**
     * @return mixed
     */
    public function getAddress1()
    {
        return $this->_address1;
    }

    /**
     * @return mixed
     */
    public function getAddress2()
    {
        return $this->_address2;
    }

    /**
     * @return mixed
     */
    public function getAddress3()
    {
        return $this->_address3;
    }

    /**
     * @return mixed
     */
    public function getCity()
    {
        return $this->_city;
    }

    /**
     * @return mixed
     */
    public function getProfileImage()
    {
        return $this->_profileImage;
    }
    //this method type casts, this is needed because php cant type cast natively for user defined classes
    public static function cast(UserData $obj){
        return $obj;
    }

}


