<?php
/**
 * Created by PhpStorm.
 * User: zmahm
 * Date: 19/12/2018
 * Time: 14:39
 */
require_once('../Models/CampsiteData.php');
require_once('../Models/Database.php');
require_once('../Models/UserData.php');

class rating
{
    private $_campsite, $_rating, $_user, $_dbInstance, $dbHandle, $_userRate;

    public function __construct($campsite, $rating, $user)
    {
        $this->_rating = $rating;
        $this->_campsite = CampsiteData::_cast($campsite);
        $this->_dbInstance = Database::getInstance();
        $this->dbHandle = $this->_dbInstance->getdbConnection();
        $this->_user = UserData::cast($user);


    }

    //checks if user has rated before
    public function hasRated()
    {
        $hasUpload = false;
        $campId = $this->_campsite->getCampsiteId();
        if ($this->_user->getRatedList() === "no rating") {
            $hasUpload = true;
            return $hasUpload;
        } else {
            $userRating = explode(",", $this->_user->getRatedList());
            foreach ($userRating as $id) {
                if ($id != $campId . ".1" or $id != $campId . ".2" or $id != $campId . ".3" or $id != $campId . ".4" or $id != $campId . ".5") {
                    $hasUpload = true;
                } else {
                    $hasUpload = false;
                }
            }
        }
        return $hasUpload;

    }

    //checks if user has rated, if they have rated and also trying to give the same rating it will return false
    public function canRate()
    {
        if ($this->hasRated()) {
            $userRating = explode(",", $this->_user->getRatedList());
            foreach ($userRating as $id) {
                if ($id === $this->getCampsite()->getCampsiteId() . "." . $this->_rating) {
                    return false;

                }
            }
            return true;

        } else {
            return true;
        }
    }

    /**
     * @return UserData
     */
    public function getUser(): UserData
    {
        return $this->_user;
    }


    /**
     * @return CampsiteData
     */
    public function getCampsite(): CampsiteData
    {
        return $this->_campsite;
    }

    /**
     * @return mixed
     */
    public function getRating()
    {
        return $this->_rating;
    }

    /**takes field and explodes into an array, if no rating currently exists, rating is added into position as serialized string.
     * If user has already rated previous rating decreases and new rating increases, i.e. user previously rated 5 stars, changed to 4 so total number of
     * 5 star rating decreases
     *
     * */
    private function calcRating()
    {
        $id = $this->_campsite->getCampsiteId();
        $curRating = $this->_campsite->getRating();
        $usrRating = $this->_rating;
        $arr = null;
        if ($this->hasRated()) {
            $arr = explode(",", $curRating);
            $one = (int)$arr[0];
            $two = (int)$arr[1];
            $three = (int)$arr[2];
            $four = (int)$arr[3];
            $five = (int)$arr[4];

            $list = explode(",", $this->_user->getRatedList());

            if (in_array($id . ".1", $list)) {
                $arr[0] = "" . (--$one) . "";

            } elseif (in_array($id . ".2", $list)) {
                $arr[1] = "" . (--$two) . "";
            } elseif (in_array($id . ".3", $list)) {
                $arr[2] = "" . (--$three) . "";
            } elseif (in_array($id . ".4", $list)) {
                $arr[3] = "" . (--$four) . "";
            } elseif (in_array($id . ".5", $list)) {
                $arr[4] = "" . (--$five) . "";
            }

        }

        if ($curRating === "not rated") {
            if ($usrRating == "1") {
                $newRating = "1,0,0,0,0";
            }
            if ($usrRating == "2") {
                $newRating = "0,1,0,0,0";
            }
            if ($usrRating == "3") {
                $newRating = "0,0,1,0,0";
            }
            if ($usrRating == "4") {
                $newRating = "0,0,0,1,0";
            }
            if ($usrRating == "5") {
                $newRating = "0,0,0,0,1";
            }
        } else {
            if ($arr == null) {
                $arr = explode(",", $curRating);

            }
            $one = (int)$arr[0];
            $two = (int)$arr[1];
            $three = (int)$arr[2];
            $four = (int)$arr[3];
            $five = (int)$arr[4];

            if ($usrRating == "1") {
                $one++;
            }
            if ($usrRating == "2") {
                $two++;
            }
            if ($usrRating == "3") {
                $three++;
            }
            if ($usrRating == "4") {
                $four++;
            }
            if ($usrRating == "5") {
                $five++;
            }
            $newRating = "" . $one . "," . $two . "," . $three . "," . $four . "," . $five . "";
        }
        return $newRating;
    }

//adds rating to campsite using pdo
    public function confirmRating()
    {
        $newList = $this->calcRating();
        $id = $this->_campsite->getCampsiteId();

        $sqlQuery = "UPDATE Campsite SET rating = ? WHERE CampsitesID = ?";
        $statement = $this->dbHandle->prepare($sqlQuery);
        $statement->bindParam(1, $newList);
        $statement->bindParam(2, $id);
        $statement->execute();
    }

//adjusts list to correct values, if user has rated the rating count previously corrected version is replaced
    public function formatList()
    {
        $id = $this->_campsite->getCampsiteId();
        if ($this->hasRated()) {
            $list = explode(",", $this->_user->getRatedList());
            if (in_array($id . ".1", $list)) {
                $index = array_search($id . ".1", $list);
            } elseif (in_array($id . ".2", $list)) {
                $index = array_search($id . ".2", $list);

            } elseif (in_array($id . ".3", $list)) {
                $index = array_search($id . ".3", $list);

            } elseif (in_array($id . ".4", $list)) {
                $index = array_search($id . ".4", $list);

            } elseif (in_array($id . ".5", $list)) {
                $index = array_search($id . ".5", $list);
            }

            $list[$index] = $this->_campsite->getCampsiteId() . "." . $this->getRating();

            $confList = implode(",", $list);
            return $confList;

        }

        if ($this->_user->getRatedList() === "no rating") {
            $confList = $this->_campsite->getCampsiteId();
        } else {
            $confList = $this->_user->getRatedList() . ',' . $id . "." . $this->getRating();
        }
        return $confList;
    }

    //updates the list using PDO object
    public function updateList()
    {
        $confList = $this->formatList();
        $id = $this->_user->getUserId();
        $sqlQuery = "UPDATE User SET ratedList= ? WHERE UserID = ?";
        $statement = $this->dbHandle->prepare($sqlQuery);
        $statement->bindParam(1, $confList);
        $statement->bindParam(2, $id);
        $statement->execute();

    }

}