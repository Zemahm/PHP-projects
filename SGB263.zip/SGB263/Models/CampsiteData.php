<?php
//This class is used to hold campsite data and is instantiated when queries are run for campsites as well as other places
class CampsiteData
{

    private $_campsiteId, $_campsiteName, $_address, $_images, $_ownerPhoneNum, $_ownerEmail, $_city, $_ownerData, $_facilities, $_rating, $_mostRated, $_image1, $_image2, $_image3, $_openingDate , $monthlyClicks, $overallClicks;

//calls defImages function
    public function __construct($dbRow)
    {
        $this->_campsiteId = $dbRow['CampsitesID'];
        $this->_campsiteName = $dbRow['CampsiteName'];
        $this->_images = $dbRow['Images'];
        $this->_address = $dbRow['Address'];
        $this->_ownerPhoneNum = $dbRow['PhoneNum'];
        $this->_ownerEmail = $dbRow['Email'];
        $this->_city = $dbRow['City'];
        $this->_facilities = $dbRow['Facilities'];
        $this->_rating = $dbRow['rating'];
        $this->_openingDate = $dbRow['OpeningDates'];
        $this->monthlyClicks = (int)($dbRow['MonthlyClicks']);
        $this->overallClicks = (int)($dbRow['OverallClicks']);
        $this->defImages();
        $this->_mostRated = $this->mostRated();
        $this->_ownerData = null;


    }

//explodes ratings into an array and checks which element has the highest value, highest rated element is returned number
    private function mostRated(){

        if ($this->_rating != "not rated") {
            $arr = explode(",", $this->_rating);

            //base case
            $value = (int)$arr[0];
            //used to know what position of the array to call back
            $i = -1;
            $pos = 0;
            foreach ($arr as $element){
                $i++;
                if ($value < (int)$element){
                    $value = (int)$element;
                    //array position
                    $pos = $i;

                }

            }

            return "Average: ".($pos+1) ." Stars";



        }
        else{
            return "Not Rated";
        }

    }


    //Takes images and spreads them into their own fields, if no images exist, default image is given
    private function defImages()
    {
        //in database images are parted by commas, puts images into their fields depending on if there are enough images
        if (!($this->getImages() === "No Images Given")) {
            $imgArray = explode(",", $this->getImages());

            $this->_image1 = $imgArray[0];

            if (!($imgArray[1] == null)) {
                $this->_image2 = $imgArray[1];
            }



            if (!($imgArray[2] == null)) {
                $this->_image3 = $imgArray[3];
            }


        } else {
            $this->_image1 = "../images/resources/noimagegiven.png";

            $this->_image2 = "../images/resources/noimagegiven.png";

            $this->_image3 = "../images/resources/noimagegiven.png";
        }

    }

    /**
     * @return mixed
     */
    public function getMonthlyClicks()
    {
        return $this->monthlyClicks;
    }

    /**
     * @param mixed $monthlyClicks
     */
    public function setMonthlyClicks($monthlyClicks)
    {
        $this->monthlyClicks = $monthlyClicks;
    }

    /**
     * @return mixed
     */
    public function getOverallClicks()
    {
        return $this->overallClicks;
    }

    /**
     * @param mixed $overallClicks
     */
    public function setOverallClicks($overallClicks)
    {
        $this->overallClicks = $overallClicks;
    }



    /**
     * @return string
     */
    public function getMostRated(): string
    {
        return $this->_mostRated;
    }

    /**
     * @return mixed
     */
    public function getOpeningDate()
    {
        return $this->_openingDate;
    }




    /**
     * @return mixed
     */
    public function getImage1()
    {
        return $this->_image1;
    }

    /**
     * @return mixed
     */
    public function getImage2()
    {
        return $this->_image2;
    }

    /**
     * @return mixed
     */
    public function getImage3()
    {
        return $this->_image3;
    }



    /**
     * @return mixed
     */
    public function getCity()
    {
        return $this->_city;
    }

    /**
     * @return mixed
     */
    public function getFacilities()
    {
        return $this->_facilities;
    }

    /**
     * @return mixed
     */
    public function getRating()
    {
        return $this->_rating;
    }


    /**
     * @return null
     */
    public function getOwnerData()
    {
        return $this->_ownerData;
    }

    /**
     * @param null $ownerData
     */
    public function setOwnerData($ownerData)
    {
        $this->_ownerData = new UserData($ownerData);
    }

    /**
     * @return mixed
     */
    public function getOwnerPhoneNum()
    {
        return $this->_ownerPhoneNum;
    }

    /**
     * @return mixed
     */
    public function getOwnerEmail()
    {
        return $this->_ownerEmail;
    }


    /**
     * @return mixed
     */
    public function getCampsiteId()
    {
        return $this->_campsiteId;
    }

    /**
     * @return mixed
     */
    public function getCampsiteName()
    {
        return $this->_campsiteName;
    }

    /**
     * @return mixed
     */
    public function getAddress()
    {
        return $this->_address;
    }

    /**
     * @return mixed
     */
    public function getImages()
    {
        return $this->_images;
    }


//this method allows type casting outside of class
    public static function _cast(CampsiteData $obj)
    {
        return $obj;
    }


}