<?php

require_once 'Database.php';
require_once 'UserData.php';
//class is used to collect user data from database into an array
class UserDataset{
    protected $_dbHandle, $_dbInstance;

    public function __construct() {

            $this->_dbInstance = Database::getInstance();
            $this->_dbHandle = $this->_dbInstance->getdbConnection();

    }

    public function fetchAllUsers() {
        $sqlQuery = 'SELECT * FROM User';

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row = $statement->fetch()) {


            $dataSet[] = new UserData($row);
        }
        return $dataSet;
    }
}



