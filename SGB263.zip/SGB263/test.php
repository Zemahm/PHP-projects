<?php
include_once('Models/Database.php');


$something = Database::getInstance();

$db = $something->getdbConnection();



$query = "SELECT * FROM StatCheck WHERE Type = 'MonthClickCheck' ";

$statement = $db->prepare($query);

//echo $statement->execute();
//var_dump( $statement->fetchAll());

//
//$statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
//$statement->execute(); // execute the PDO statement

$cheese = getdate();

var_dump($cheese);