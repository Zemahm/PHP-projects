function favourite(id) {
    document.write(co)

}